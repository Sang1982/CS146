
import java.util.Random;
import java.util.Scanner;
/*@ author
Sang Nguyen
011967423.*/

public class patientClinicRoom{
    // declare Name and Priority for Patient.
    public static class Patient {

        private String name;
        private int priority;
        // Define the content for Name and priority.

        public Patient(String name, int priority) {
            this.name = name;
            this.priority = priority;
        }
        // declare when array gets no patients
        public Patient(){
            this.priority= 0;
            this.name=" ";
        }
        // Set string name.
        public void setName(String name){
            this.name = name;
        }
        // Set Int name.
        public void setPriority(int priority){
            this.priority = priority;
        }
        // Get string name.
        public String getName(){
            return this.name;
        }
        // Get Int name.
        public  int getPriority(){
            return this.priority;
        }

        @Override
        // printout (name, and priority).
        public String toString(){
            return "Name: " + name + ", priority: " + priority;
        }
    }
    // List name give to get random.
    private static String[] names = {"Sang", "Tien", "Thong", "Khoa", "Mike", "Phuc", "Jenny", "Mors", "Kim", "Ryback",
            "Alexander", "Vanessa", "Julie", "Jacob", "Jason", "Jack", "Rose","Phuong ", " Mohamet", "April", "Phung",
            "Kenny", "Calvin", "Dylan", "Lisa", "Hari", "Rivas", "Ricardo", "Ronaldo", "Messi", "Ibrahimovic",
            "Neuer", "Arsene", "Wagner", "Love", "Melissa", "Terry", "Lampard", "Gerrard"  };
    // default: 20 people at a time
    private static int numberOfPatients = 20;
    // declare random.
    public static Random rand = new Random();

    public static void main(String[] args){

        char repeat = 'y';
        Scanner sc = new Scanner(System.in);
        // Create a list of Patient.
        Patient[] Plist = createPatientList();
        // create a do while loop.
        do{
            System.out.println(" --------------- Wellcome to Clinic Room----------------");
            System.out.println("-----------Here is Patient's Information----------------");
            System.out.println(" ------------------------Menu---------------------------");
            System.out.println(" 1 : MaxHeapify, BuildMaxHeap ");
            System.out.println(" 2 : HeapExtractMax ");
            System.out.println(" 3 : MaxHeapInsert ");
            System.out.println(" 4 : HeapSort ");
            System.out.println(" 5 : Call the next patient for Treatment ( heapMaximum)");
            System.out.println(" 6 : Boost a waiting patient up (heapIncreaseKey)");
            System.out.println(" 9 : Quit.");
            System.out.println(" --------------------------------------------------------");
            System.out.print  (" Choose :   ");
            switch (sc.nextInt()) {
                case 1:
                    if ( numberOfPatients > 0) {
                        buildMaxHeap(Plist);
                        maxHeapify(Plist,0, numberOfPatients);

                        for(Patient patient: Plist) {
                            System.out.println(patient.toString());
                        }
                    }
                    else
                        System.out.println(" At present, No any Patient in here, wellcome!!");
                  numbersofPaitentinroom(Plist);
                    break;
                case 2:
                    heapExtractMax(Plist);
                    buildMaxHeap(Plist);
                    for(Patient patient: Plist) {
                        System.out.println(patient.toString());
                    }
                    numbersofPaitentinroom(Plist);

                    break;
                case 3:

                    if (numberOfPatients>=20){
                        System.out.println(" The room is full ( 20 patients)");
                        System.out.println( "  can not insert the patient!!!");
                    }else {
                        Scanner sc1 = new Scanner(System.in);

                        Patient b = new Patient();
                        System.out.println(" Call the next patient");
                        System.out.print("\nEnter a name of new Patient  ");
                        b.setName(sc1.nextLine());
                        System.out.print("\nEnter a priority number of new Patient (= < 100)  ");
                        b.setPriority(sc1.nextInt());
                        if ( b.getPriority() >100){
                            System.out.println(" \n New Patient  is out of range. ");
                        }
                        else {

                            maxHeapInsert(Plist,b );
                            buildMaxHeap(Plist);

                            for(Patient patient: Plist) {
                                System.out.println(patient.toString());
                            }
                            numbersofPaitentinroom(Plist);
                        }
                    }
                    break;
                case 4:
                    buildMaxHeap(Plist);
                    heapSort(Plist);

                    for(Patient patient: Plist) {
                        System.out.println(patient.toString());
                    }
                    numbersofPaitentinroom(Plist);
                    break;
                case 5:
                    buildMaxHeap(Plist);
                    System.out.println(" The Patient for next treatment is:" + heapMaximum(Plist)  );
                    numbersofPaitentinroom(Plist);
                    break;
                case 6:
                    buildMaxHeap(Plist);
                    Scanner sc2 = new Scanner(System.in);
                    //buildMaxHeap(Plist);
                    System.out.println("\n At present name of list Patient :   ");
                    int i =0;
                    for(Patient patient: Plist) {
						i++;
                        System.out.println(  " number : " +i +"  "  + patient.toString());
                    }
                    System.out.println(" The new priority that you give for new paitient: ");
                    System.out.println("\nEnter a new priority number (<=100) :  ");
                    int  n = sc2.nextInt();
                    System.out.println("\nEnter a number of Patient for boosting (<=19):  ");
                    int m = sc2.nextInt();
                    heapIncreaseKey( Plist, m , n);
                    heapSort(Plist);
                    for(Patient patient: Plist) {
                        System.out.println(patient.toString());
                    }
                    numbersofPaitentinroom(Plist);
                    break;

                case 9:
                    repeat = 'n';
                    break;
            }

        }
        while(repeat != 'n');
    }
    // Create a funtion of patient list.
    public static Patient[] createPatientList(){
        // starting index is 0
        Patient[] Plist = new Patient[numberOfPatients];
        Plist[0] = new Patient();
        // get name anh priority for 20 patients.
        for(int k= 0; k <= Plist.length - 1; k++) {
            Plist[k] = new Patient(newPatient(Plist,k).getName(), newPatient(Plist,k).getPriority());
        }

        return Plist;
    }
    // Create a funtion of  new patient.
    public static Patient newPatient(Patient[] Plist, int k){
        // get random name in name table.
        int listname = rand.nextInt(names.length-1 );
        // // get random priority number in range 100
        int priority = rand.nextInt(100) ;
        int a = 0;
        // Avoiding case 2 paitient get same priority.
        while(a < k){
            if(Plist[a].getPriority() != priority ) {
                a++;
            } else {
                //( avoid priority =0).
                priority = rand.nextInt(99+2) ;
            }
        }

        Patient newPatient = new Patient(names[listname], priority);

        return newPatient;
    }
    //create a public funtion to know number patient being in hospital.
    public static void numbersofPaitentinroom (Patient[] Plist) {

        int index =Plist.length-1;
        if (Plist[index].getPriority() > 0)
            System.out.println(" the number of patients in Emergency room in this time is "
                    + 20);
        else {
            int z=0;
            for (int i = 0; i <= numberOfPatients ; i++) {
                if (Plist[i].getPriority() == 0) {
                    z= i;
                }
            }
            System.out.println(" the number of patients in Emergency room in this time is "
                    + (z));
        }
    }
    //create a private funtion to change order of 2  patients
    private static void change(Patient PA, Patient PB){

        Patient PC = new Patient();
        PC.setName(PA.getName());
        PC.setPriority(PA.getPriority());
        PA.setName(PB.getName());
        PA.setPriority(PB.getPriority());
        PB.setName(PC.getName());
        PB.setPriority(PC.getPriority());
    }
    //create a public funtion to get maxHeapify in list 20 patients.
    public static void maxHeapify(Patient[] Plist, int Patient1, int numberOfPatients){
        // get largest = patient1.
        int largest =Patient1 ;
        // on the left child we got
        int leftChild = 2 * Patient1 +1;
        // on the right child we got
        int rightChild = 2* Patient1 +2 ;
        if(leftChild <= numberOfPatients-1  && Plist[leftChild].getPriority() > Plist[Patient1].getPriority() )
            largest = leftChild;
        else
            largest = Patient1;
        if(rightChild <= numberOfPatients-1 && Plist[rightChild].getPriority() > Plist[largest].getPriority() )
            largest = rightChild;

        if(largest != Patient1)
        {
            change (Plist[Patient1] , Plist[largest]);
            maxHeapify (Plist, largest, numberOfPatients);
        }
    }
    //create a public funtion to to get buildMaxHeap.
    public static void buildMaxHeap(Patient[] Plist){
        for(int i = numberOfPatients-1/2 ; i >= 0 ; i-- )
        {
            maxHeapify(Plist, i, numberOfPatients) ;
        }
    }
    // /create a public funtion to get Heapsort.
    public static void heapSort(Patient[] Plist){
        int newNumberOfPatients = numberOfPatients;
        buildMaxHeap(Plist);
        for(int i = numberOfPatients - 1; i >= 0; i--){
            change(Plist[0], Plist[i]);
            newNumberOfPatients--;
            maxHeapify(Plist, 0, newNumberOfPatients);
        }
    }
    //create a public funtion to get maxheapInsert.
    public static int maxHeapInsert(Patient[] Plist , Patient newPatient1) {

        int index = numberOfPatients;

        Patient a = new Patient();
        buildMaxHeap(Plist);
        Plist[index]= newPatient(Plist,0 );
        numberOfPatients++;
        // Increase key after insert new patient
        while (index > 1 && Plist[index/2].getPriority() > newPatient1.getPriority()) {
            a= Plist[index];
            Plist[index] = Plist[index/2];
            Plist[index] = a;

            index=index/2;
        }
        // Because not important patient so new patient will get priority number less than the patient get same priority number in the list.
        for ( int f =0; f < Plist.length; f++ ) {
            if ( Plist[f].getPriority()== newPatient1.getPriority())
                newPatient1.setPriority(newPatient1.getPriority()-1);
        }
        Plist[index]= newPatient1;
        return index ;
    }
    //create a public funtion to get ExtractMax.
    public static Patient heapExtractMax(Patient[] Plist) {
        buildMaxHeap(Plist);
        System.out.println(" The old patient name has finished treatment is : " + Plist[0].getName());
        Patient nextPatient = new Patient();
        Plist[0]=Plist[numberOfPatients-1];

        Plist[numberOfPatients-1]= nextPatient;

        numberOfPatients--;

        maxHeapify( Plist, 0, numberOfPatients);

        return nextPatient;

    }
    //create a public funtion to get ExtractMax.
    public static void heapIncreaseKey(Patient[] Plist, int i, int newpriority){
        System.out.println(" The old patient name is : " + Plist[i].getName());
        System.out.println(" Priority old number is :  " +  Plist[i].getPriority());
        // do nothing when the new priority is less than the current
        if(newpriority < Plist[i].getPriority())
            return;
        // if the new priority is less than the current set newpriority for patient number i.
        Plist[i].setPriority(newpriority);
        // heapIncreaseKey
        while(i > 1 && Plist[i / 2].getPriority() < Plist[i].getPriority()){
            change(Plist[i/2], Plist[i]);
            i /= 2;
        }
        buildMaxHeap(Plist);
        // Because this important patient so new patient will get priority number greater than the patient get same priority number in the list.
        for ( i = Plist.length-1; i>=0; i--){
            if ( Plist[i].getPriority()== newpriority && Plist[i+1].getPriority()== newpriority)
                Plist[i].setPriority(Plist[i].getPriority()+ 1);
        }

    }
    //create a public funtion to get heapMaximum.
    public static Patient heapMaximum(Patient[] _patients){
        return _patients[0];
    }


}
